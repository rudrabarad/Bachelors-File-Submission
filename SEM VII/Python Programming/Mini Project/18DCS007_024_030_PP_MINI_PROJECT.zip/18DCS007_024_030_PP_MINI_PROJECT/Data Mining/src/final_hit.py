def get_em(tweets, srch):
    pos = []
    neg = []
    nut = []

    tw_len = len(tweets)
    for a_tweet in tweets:
        if a_tweet['sentiment'] > 0:
            pos.append(a_tweet)
        elif a_tweet['sentiment'] < 0:
            neg.append(a_tweet)
        else:
            nut.append(a_tweet)
    get_per = lambda x: (100*(len(x)))/tw_len
    if tw_len==0:
        print('Sorry..!! Unable to find any tweets on the subject You Searched for')
    else:
        print("\nSentiment Analysis for {}:".format(srch))

        print("Positive tweets: ", end=' ')
        try:
            print(get_per(pos))
        except ZeroDivisionError:
            print(0)

        print("Negative tweets: ", end=' ')
        try:
            print(get_per(neg))
        except ZeroDivisionError:
            print(0)

        print("Neutral tweets:  ", end=' ')
        try:
            print(get_per(nut))
        except ZeroDivisionError:
            print(0)
