from tweepy import OAuthHandler, API, TweepError


def auth():

    consumer_key = "s9fx1FEEviyRds0S2ImdAAlkw"  # API Key
    consumer_secret = "6K9HAahrdmqpnxRZhskJGnIopXXW3xpKHLP1YCmgr6KEsktEmG"  # API Secret
    # copy-paste the whole key wheather its like:- xxxxxxxxx-xxxxxxxxxxxxxxx or whatever
    access_token = "1160221780306354176-YlyqQLDhiNT4Bz8sN3W2xgbO40GFhH"
    access_token_secret = "itwTs0k47ieiq2pM8eV7EgMzdZabjAZhifflFCr9yq1oD"

    try:
        # initialize the Oauth object for OAuthHandler class in tweepy module
        # parameters are consumer key, consumer_secret and callback(optional)
        oauth = OAuthHandler(consumer_key, consumer_secret)
        oauth.set_access_token(access_token, access_token_secret)
        username = OAuthHandler.get_username(oauth)
        api = API(oauth)
        yield api
        yield  username
    except TweepError:
        return 0
